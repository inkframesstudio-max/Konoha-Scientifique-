# 📚 Bibliothèque Konoha - Guide de Déploiement

## ✅ Fichiers créés

1. **index.jsx** - Composant React principal (pages/index.jsx)
2. **package.json** - Dépendances du projet
3. **next.config.js** - Configuration Next.js pour Vercel

## 🚀 Étapes de déploiement

### Option 1 : Avec Git (recommandé)

```bash
# 1. Cloner ou créer votre repo
git clone https://github.com/VOTRE_USER/konoha-library.git
cd konoha-library

# 2. Copier les fichiers
# - Mettre index.jsx dans: pages/index.jsx
# - Remplacer package.json
# - Remplacer next.config.js

# 3. Installer les dépendances
npm install

# 4. Tester localement
npm run dev
# Puis ouvrir http://localhost:3000

# 5. Push vers GitHub
git add .
git commit -m "Rebuild avec édition des livres et persistence IndexedDB"
git push origin main

# 6. Vercel va rebuild automatiquement ! ✨
```

### Option 2 : Déploiement direct sur Vercel

```bash
# 1. Installez Vercel CLI
npm i -g vercel

# 2. Depuis le dossier du projet
vercel

# Suivez les prompts et choisissez votre projet existant
```

## 📋 Structure du dossier

```
konoha-library/
├── pages/
│   └── index.jsx          ← Le fichier React
├── public/
│   └── (fichiers statiques)
├── package.json           ← Dépendances
├── next.config.js         ← Config
├── .gitignore
└── README.md
```

## 🎯 Fonctionnalités incluses

✅ **Restauration automatique** des données du backup JSON
✅ **Édition des livres** (titre, auteur)
✅ **Ajout/suppression de pages** 
✅ **Modification du contenu** des pages
✅ **Persistence IndexedDB** (données sauvegardées localement)
✅ **Pas de rafraîchissement permanent** (gestion d'état optimisée)
✅ **UI responsive** (fonctionne sur mobile aussi)

## 🔄 Données sauvegardées

- Les livres et pages sont automatiquement synchronisés avec IndexedDB
- Au premier chargement, le backup JSON est restauré
- Les modifications sont sauvegardées instantanément

## 🐛 Dépannage

**Si ça ne marche pas:**
1. Vérifiez que Node.js 16+ est installé: `node --version`
2. Supprimez node_modules: `rm -rf node_modules`
3. Réinstallez: `npm install`
4. Testez localement: `npm run dev`

**Si Vercel dit "Build failed":**
- Allez dans Settings > Build & Development Settings
- Vérifiez que la Command est: `npm run build`
- Output Directory: `.next`

## 📞 Support

Tout est dans le code ! Les données du backup `konoha-backup.json` sont intégrées directement dans le composant React.

---

**Prêt à déployer ? 🚀**
