import React, { useState, useEffect } from 'react';

// Données du backup intégrées
const BACKUP_DATA = {
  "KonohaLibraryDB": {
    "version": 5,
    "stores": {
      "books": [
        {
          "key": "book-1782924408054",
          "value": {
            "id": "book-1782924408054",
            "sectionId": "sec-mineraux",
            "title": "Recueille de minéraux et cristaux",
            "author": "Tuyka Itsuri",
            "theme": "",
            "color": "#1a472a",
            "textColor": "#ffffff",
            "pages": [
              {
                "id": "page-1",
                "title": "Introduction",
                "content": "Les minéraux et cristaux sont des merveilles naturelles..."
              }
            ]
          }
        }
      ],
      "sections": [
        {
          "key": "sec-expedition",
          "value": {
            "id": "sec-expedition",
            "name": "Expédition"
          }
        },
        {
          "key": "sec-mineraux",
          "value": {
            "id": "sec-mineraux",
            "name": "Minéraux & Cristaux"
          }
        }
      ],
      "testAttempts": []
    }
  }
};

export default function KonohaLibrary() {
  const [books, setBooks] = useState([]);
  const [sections, setSections] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [editMode, setEditMode] = useState(false);
  const [dbInitialized, setDbInitialized] = useState(false);

  // Initialiser IndexedDB une seule fois
  useEffect(() => {
    if (dbInitialized) return;

    const initDB = async () => {
      try {
        const request = indexedDB.open('KonohaLibraryDB', 5);

        request.onupgradeneeded = (event) => {
          const db = event.target.result;
          if (!db.objectStoreNames.contains('books')) {
            db.createObjectStore('books', { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains('sections')) {
            db.createObjectStore('sections', { keyPath: 'id' });
          }
          if (!db.objectStoreNames.contains('testAttempts')) {
            db.createObjectStore('testAttempts', { keyPath: 'id' });
          }
        };

        request.onsuccess = () => {
          const db = request.result;
          const txn = db.transaction(['books', 'sections'], 'readonly');
          
          let loadedBooks = [];
          let loadedSections = [];

          const booksStore = txn.objectStore('books');
          const booksRequest = booksStore.getAll();
          booksRequest.onsuccess = () => {
            loadedBooks = booksRequest.result.length > 0 ? booksRequest.result : BACKUP_DATA.KonohaLibraryDB.stores.books.map(b => b.value);
          };

          const sectionsStore = txn.objectStore('sections');
          const sectionsRequest = sectionsStore.getAll();
          sectionsRequest.onsuccess = () => {
            loadedSections = sectionsRequest.result.length > 0 ? sectionsRequest.result : BACKUP_DATA.KonohaLibraryDB.stores.sections.map(s => s.value);
          };

          txn.oncomplete = () => {
            setBooks(loadedBooks);
            setSections(loadedSections);
            setDbInitialized(true);
          };
        };
      } catch (error) {
        console.error('Erreur IndexedDB:', error);
        setBooks(BACKUP_DATA.KonohaLibraryDB.stores.books.map(b => b.value));
        setSections(BACKUP_DATA.KonohaLibraryDB.stores.sections.map(s => s.value));
        setDbInitialized(true);
      }
    };

    initDB();
  }, [dbInitialized]);

  // Persister les données dans IndexedDB
  const saveToIndexedDB = async (data, storeName) => {
    try {
      const request = indexedDB.open('KonohaLibraryDB', 5);
      request.onsuccess = () => {
        const db = request.result;
        const txn = db.transaction(storeName, 'readwrite');
        const store = txn.objectStore(storeName);
        store.put(data);
      };
    } catch (error) {
      console.error('Erreur sauvegarde:', error);
    }
  };

  const updateBook = (updatedBook) => {
    const newBooks = books.map(b => b.id === updatedBook.id ? updatedBook : b);
    setBooks(newBooks);
    setSelectedBook(updatedBook);
    saveToIndexedDB(updatedBook, 'books');
  };

  const addPage = (bookId) => {
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    const newPage = {
      id: `page-${Date.now()}`,
      title: 'Nouvelle page',
      content: 'Contenu vide...'
    };

    const updatedBook = {
      ...book,
      pages: [...(book.pages || []), newPage]
    };

    updateBook(updatedBook);
  };

  const updatePage = (bookId, pageId, updatedPage) => {
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    const updatedBook = {
      ...book,
      pages: book.pages.map(p => p.id === pageId ? updatedPage : p)
    };

    updateBook(updatedBook);
  };

  const deletePage = (bookId, pageId) => {
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    const updatedBook = {
      ...book,
      pages: book.pages.filter(p => p.id !== pageId)
    };

    updateBook(updatedBook);
  };

  if (!dbInitialized) {
    return <div style={styles.loading}>Chargement de la bibliothèque...</div>;
  }

  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1>📚 Bibliothèque Konoha</h1>
        <p>Gestion et édition des livres</p>
      </header>

      <div style={styles.mainContent}>
        {/* Liste des livres */}
        <div style={styles.sidebar}>
          <h2>Livres</h2>
          {books.map(book => (
            <div
              key={book.id}
              style={{
                ...styles.bookItem,
                backgroundColor: selectedBook?.id === book.id ? book.color : '#f0f0f0',
                color: selectedBook?.id === book.id ? book.textColor : '#000'
              }}
              onClick={() => {
                setSelectedBook(book);
                setEditMode(false);
              }}
            >
              <div style={styles.bookTitle}>{book.title}</div>
              <div style={styles.bookAuthor}>par {book.author}</div>
              <div style={styles.pageCount}>{book.pages?.length || 0} pages</div>
            </div>
          ))}
        </div>

        {/* Détails du livre */}
        <div style={styles.content}>
          {selectedBook ? (
            <>
              <div style={styles.bookHeader}>
                <h2>{selectedBook.title}</h2>
                <p style={styles.author}>par {selectedBook.author}</p>
                <button 
                  onClick={() => setEditMode(!editMode)}
                  style={{
                    ...styles.button,
                    backgroundColor: editMode ? '#d32f2f' : '#1976d2'
                  }}
                >
                  {editMode ? '❌ Quitter édition' : '✏️ Éditer'}
                </button>
              </div>

              {editMode && (
                <div style={styles.editSection}>
                  <h3>Éditer le livre</h3>
                  <input
                    type="text"
                    placeholder="Titre"
                    value={selectedBook.title}
                    onChange={(e) => updateBook({ ...selectedBook, title: e.target.value })}
                    style={styles.input}
                  />
                  <input
                    type="text"
                    placeholder="Auteur"
                    value={selectedBook.author}
                    onChange={(e) => updateBook({ ...selectedBook, author: e.target.value })}
                    style={styles.input}
                  />
                  <button 
                    onClick={() => addPage(selectedBook.id)}
                    style={styles.addPageButton}
                  >
                    ➕ Ajouter une page
                  </button>
                </div>
              )}

              {/* Pages du livre */}
              <div style={styles.pagesSection}>
                <h3>Pages ({selectedBook.pages?.length || 0})</h3>
                {selectedBook.pages && selectedBook.pages.length > 0 ? (
                  <div style={styles.pagesList}>
                    {selectedBook.pages.map((page, index) => (
                      <div key={page.id} style={styles.pageItem}>
                        <div style={styles.pageNumber}>Page {index + 1}</div>
                        
                        {editMode ? (
                          <div style={styles.pageEdit}>
                            <input
                              type="text"
                              placeholder="Titre de la page"
                              value={page.title}
                              onChange={(e) => updatePage(selectedBook.id, page.id, { ...page, title: e.target.value })}
                              style={styles.input}
                            />
                            <textarea
                              placeholder="Contenu de la page"
                              value={page.content}
                              onChange={(e) => updatePage(selectedBook.id, page.id, { ...page, content: e.target.value })}
                              style={styles.textarea}
                            />
                            <button
                              onClick={() => deletePage(selectedBook.id, page.id)}
                              style={styles.deleteButton}
                            >
                              🗑️ Supprimer
                            </button>
                          </div>
                        ) : (
                          <div style={styles.pageView}>
                            <h4>{page.title}</h4>
                            <p>{page.content}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p style={styles.emptyState}>Pas de pages. {editMode && 'Cliquez sur "Ajouter une page" pour en créer.'}</p>
                )}
              </div>
            </>
          ) : (
            <div style={styles.emptyState}>
              <p>Sélectionnez un livre pour commencer</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    height: '100vh',
    display: 'flex',
    flexDirection: 'column',
    backgroundColor: '#fafafa'
  },
  loading: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    height: '100vh',
    fontSize: '18px'
  },
  header: {
    backgroundColor: '#1a472a',
    color: '#ffffff',
    padding: '20px',
    textAlign: 'center',
    boxShadow: '0 2px 4px rgba(0,0,0,0.1)'
  },
  mainContent: {
    display: 'flex',
    flex: 1,
    overflow: 'hidden'
  },
  sidebar: {
    width: '280px',
    backgroundColor: '#ffffff',
    borderRight: '1px solid #e0e0e0',
    overflowY: 'auto',
    padding: '20px'
  },
  bookItem: {
    padding: '12px',
    marginBottom: '10px',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    border: '2px solid transparent'
  },
  bookTitle: {
    fontWeight: 'bold',
    marginBottom: '4px'
  },
  bookAuthor: {
    fontSize: '12px',
    opacity: 0.7,
    marginBottom: '4px'
  },
  pageCount: {
    fontSize: '11px',
    opacity: 0.6
  },
  content: {
    flex: 1,
    overflowY: 'auto',
    padding: '30px'
  },
  bookHeader: {
    marginBottom: '30px',
    paddingBottom: '20px',
    borderBottom: '2px solid #e0e0e0'
  },
  author: {
    color: '#666',
    marginBottom: '15px'
  },
  button: {
    padding: '10px 20px',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold',
    marginRight: '10px'
  },
  editSection: {
    backgroundColor: '#f5f5f5',
    padding: '20px',
    borderRadius: '8px',
    marginBottom: '30px',
    border: '2px solid #ffb300'
  },
  input: {
    width: '100%',
    padding: '10px',
    marginBottom: '10px',
    borderRadius: '6px',
    border: '1px solid #ddd',
    fontSize: '14px',
    boxSizing: 'border-box'
  },
  textarea: {
    width: '100%',
    minHeight: '100px',
    padding: '10px',
    marginBottom: '10px',
    borderRadius: '6px',
    border: '1px solid #ddd',
    fontSize: '14px',
    fontFamily: 'inherit',
    boxSizing: 'border-box'
  },
  addPageButton: {
    padding: '10px 20px',
    backgroundColor: '#4caf50',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '14px',
    fontWeight: 'bold'
  },
  deleteButton: {
    padding: '8px 16px',
    backgroundColor: '#f44336',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    fontSize: '12px'
  },
  pagesSection: {
    marginTop: '30px'
  },
  pagesList: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(350px, 1fr))',
    gap: '20px'
  },
  pageItem: {
    backgroundColor: '#ffffff',
    border: '2px solid #e0e0e0',
    borderRadius: '8px',
    padding: '20px',
    transition: 'all 0.2s'
  },
  pageNumber: {
    fontSize: '12px',
    color: '#999',
    marginBottom: '10px',
    fontWeight: 'bold'
  },
  pageView: {
    lineHeight: '1.6'
  },
  pageEdit: {
    display: 'flex',
    flexDirection: 'column',
    gap: '10px'
  },
  emptyState: {
    textAlign: 'center',
    color: '#999',
    padding: '40px 20px',
    fontSize: '16px'
  }
};
